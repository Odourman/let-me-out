Dynamic73:
 sta WSYNC
Dynamic73Y71:
 iny
 lda PlayerRows,y
 sta.b GRP0
 lda.b CACHE+11
 ldx.b CACHE+0
 stx.b GRP1
 sty.b RESP1
 sty.b RESP0
 ldx.b CACHE+22
 sty.w RESP1
 stx.b GRP0
 sta.b GRP1
 ldx #14
 stx.b COLUP0
 sty.b RESP0
 sty.w RESP1
 lda.b CACHE+33
 sta.b GRP1
 sty.b RESP1
 lda.b CACHE+44
 sta.w GRP1
 ldx #30
 stx.b COLUP0
 nop
 nop
 nop
Dynamic73Y72:
 iny
 lda PlayerRows,y
 sta.b GRP0
 lda.b CACHE+12
 ldx.b CACHE+1
 stx.b GRP1
 sty.b RESP1
 sty.b RESP0
 ldx.b CACHE+23
 sty.w RESP1
 stx.b GRP0
 sta.b GRP1
 ldx #14
 stx.b COLUP0
 sty.b RESP0
 sty.w RESP1
 lda.b CACHE+34
 sta.b GRP1
 sty.b RESP1
 lda.b CACHE+45
 sta.w GRP1
 ldx #30
 stx.b COLUP0
 nop
 nop
 nop
Dynamic73Y73:
 iny
 lda PlayerRows,y
 sta.b GRP0
 lda.b CACHE+13
 ldx.b CACHE+2
 stx.b GRP1
 sty.b RESP1
 sty.b RESP0
 ldx.b CACHE+24
 sty.w RESP1
 stx.b GRP0
 sta.b GRP1
 ldx #14
 stx.b COLUP0
 sty.b RESP0
 sty.w RESP1
 lda.b CACHE+35
 sta.b GRP1
 sty.b RESP1
 lda.b CACHE+46
 sta.w GRP1
 ldx #30
 stx.b COLUP0
 nop
 nop
 nop
Dynamic73Y74:
 iny
 lda PlayerRows,y
 sta.b GRP0
 lda.b CACHE+14
 ldx.b CACHE+3
 stx.b GRP1
 sty.b RESP1
 sty.b RESP0
 ldx.b CACHE+25
 sty.w RESP1
 stx.b GRP0
 sta.b GRP1
 ldx #14
 stx.b COLUP0
 sty.b RESP0
 sty.w RESP1
 lda.b CACHE+36
 sta.b GRP1
 sty.b RESP1
 lda.b CACHE+47
 sta.w GRP1
 ldx #30
 stx.b COLUP0
 nop
 nop
 nop
Dynamic73Y75:
 iny
 lda PlayerRows,y
 sta.b GRP0
 lda.b CACHE+15
 ldx.b CACHE+4
 stx.b GRP1
 sty.b RESP1
 sty.b RESP0
 ldx.b CACHE+26
 sty.w RESP1
 stx.b GRP0
 sta.b GRP1
 ldx #14
 stx.b COLUP0
 sty.b RESP0
 sty.w RESP1
 lda.b CACHE+37
 sta.b GRP1
 sty.b RESP1
 lda.b CACHE+48
 sta.w GRP1
 ldx #30
 stx.b COLUP0
 nop
 nop
 nop
Dynamic73Y76:
 iny
 lda PlayerRows,y
 sta.b GRP0
 lda.b CACHE+16
 ldx.b CACHE+5
 stx.b GRP1
 sty.b RESP1
 sty.b RESP0
 ldx.b CACHE+27
 sty.w RESP1
 stx.b GRP0
 sta.b GRP1
 ldx #14
 stx.b COLUP0
 sty.b RESP0
 sty.w RESP1
 lda.b CACHE+38
 sta.b GRP1
 sty.b RESP1
 lda.b CACHE+49
 sta.w GRP1
 ldx #30
 stx.b COLUP0
 nop
 nop
 nop
Dynamic73Y77:
 iny
 lda PlayerRows,y
 sta.b GRP0
 lda.b CACHE+17
 ldx.b CACHE+6
 stx.b GRP1
 sty.b RESP1
 sty.b RESP0
 ldx.b CACHE+28
 sty.w RESP1
 stx.b GRP0
 sta.b GRP1
 ldx #14
 stx.b COLUP0
 sty.b RESP0
 sty.w RESP1
 lda.b CACHE+39
 sta.b GRP1
 sty.b RESP1
 lda.b CACHE+50
 sta.w GRP1
 ldx #30
 stx.b COLUP0
 nop
 nop
 nop
Dynamic73Y78:
 iny
 lda PlayerRows,y
 sta.b GRP0
 lda.b CACHE+18
 ldx.b CACHE+7
 stx.b GRP1
 sty.b RESP1
 sty.b RESP0
 ldx.b CACHE+29
 sty.w RESP1
 stx.b GRP0
 sta.b GRP1
 ldx #14
 stx.b COLUP0
 sty.b RESP0
 sty.w RESP1
 lda.b CACHE+40
 sta.b GRP1
 sty.b RESP1
 lda.b CACHE+51
 sta.w GRP1
 ldx #30
 stx.b COLUP0
 nop
 nop
 nop
Dynamic73Y79:
 iny
 lda PlayerRows,y
 sta.b GRP0
 lda.b CACHE+19
 ldx.b CACHE+8
 stx.b GRP1
 sty.b RESP1
 sty.b RESP0
 ldx.b CACHE+30
 sty.w RESP1
 stx.b GRP0
 sta.b GRP1
 ldx #14
 stx.b COLUP0
 sty.b RESP0
 sty.w RESP1
 lda.b CACHE+41
 sta.b GRP1
 sty.b RESP1
 lda.b CACHE+52
 sta.w GRP1
 ldx #30
 stx.b COLUP0
 nop
 nop
 nop
Dynamic73Y80:
 iny
 lda PlayerRows,y
 sta.b GRP0
 lda.b CACHE+20
 ldx.b CACHE+9
 stx.b GRP1
 sty.b RESP1
 sty.b RESP0
 ldx.b CACHE+31
 sty.w RESP1
 stx.b GRP0
 sta.b GRP1
 ldx #14
 stx.b COLUP0
 sty.b RESP0
 sty.w RESP1
 lda.b CACHE+42
 sta.b GRP1
 sty.b RESP1
 lda.b CACHE+53
 sta.w GRP1
 ldx #30
 stx.b COLUP0
 nop
 nop
 nop
Dynamic73Y81:
 iny
 lda PlayerRows,y
 sta.b GRP0
 lda.b CACHE+21
 ldx.b CACHE+10
 stx.b GRP1
 sty.b RESP1
 sty.b RESP0
 ldx.b CACHE+32
 sty.w RESP1
 stx.b GRP0
 sta.b GRP1
 ldx #14
 stx.b COLUP0
 sty.b RESP0
 sty.w RESP1
 lda.b CACHE+43
 sta.b GRP1
 sty.b RESP1
 lda.b CACHE+54
 sta.w GRP1
 ldx #30
 stx.b COLUP0
 bit FRAME
 jmp LeaveBand
Dynamic67:
 sta WSYNC
Dynamic67Y71:
 iny
 lda.b CACHE+0
 sta.b GRP1
 lda.b CACHE+11
 ldx PlayerRows,y
 stx.b GRP0
 sty.b RESP1
 sty.b RESP0
 sta.b GRP1
 sty.w RESP1
 ldx.b CACHE+22
 lda #14
 sta.w COLUP0
 sty.b RESP0
 stx.b GRP0
 sty.b RESP1
 lda.b CACHE+33
 sta.b GRP1
 sty.b RESP1
 lda.b CACHE+44
 sta.w GRP1
 lda #30
 bit FRAME
 sta.b COLUP0
 bit FRAME
Dynamic67Y72:
 iny
 lda.b CACHE+1
 sta.b GRP1
 lda.b CACHE+12
 ldx PlayerRows,y
 stx.b GRP0
 sty.b RESP1
 sty.b RESP0
 sta.b GRP1
 sty.w RESP1
 ldx.b CACHE+23
 lda #14
 sta.w COLUP0
 sty.b RESP0
 stx.b GRP0
 sty.b RESP1
 lda.b CACHE+34
 sta.b GRP1
 sty.b RESP1
 lda.b CACHE+45
 sta.w GRP1
 lda #30
 bit FRAME
 sta.b COLUP0
 bit FRAME
Dynamic67Y73:
 iny
 lda.b CACHE+2
 sta.b GRP1
 lda.b CACHE+13
 ldx PlayerRows,y
 stx.b GRP0
 sty.b RESP1
 sty.b RESP0
 sta.b GRP1
 sty.w RESP1
 ldx.b CACHE+24
 lda #14
 sta.w COLUP0
 sty.b RESP0
 stx.b GRP0
 sty.b RESP1
 lda.b CACHE+35
 sta.b GRP1
 sty.b RESP1
 lda.b CACHE+46
 sta.w GRP1
 lda #30
 bit FRAME
 sta.b COLUP0
 bit FRAME
Dynamic67Y74:
 iny
 lda.b CACHE+3
 sta.b GRP1
 lda.b CACHE+14
 ldx PlayerRows,y
 stx.b GRP0
 sty.b RESP1
 sty.b RESP0
 sta.b GRP1
 sty.w RESP1
 ldx.b CACHE+25
 lda #14
 sta.w COLUP0
 sty.b RESP0
 stx.b GRP0
 sty.b RESP1
 lda.b CACHE+36
 sta.b GRP1
 sty.b RESP1
 lda.b CACHE+47
 sta.w GRP1
 lda #30
 bit FRAME
 sta.b COLUP0
 bit FRAME
Dynamic67Y75:
 iny
 lda.b CACHE+4
 sta.b GRP1
 lda.b CACHE+15
 ldx PlayerRows,y
 stx.b GRP0
 sty.b RESP1
 sty.b RESP0
 sta.b GRP1
 sty.w RESP1
 ldx.b CACHE+26
 lda #14
 sta.w COLUP0
 sty.b RESP0
 stx.b GRP0
 sty.b RESP1
 lda.b CACHE+37
 sta.b GRP1
 sty.b RESP1
 lda.b CACHE+48
 sta.w GRP1
 lda #30
 bit FRAME
 sta.b COLUP0
 bit FRAME
Dynamic67Y76:
 iny
 lda.b CACHE+5
 sta.b GRP1
 lda.b CACHE+16
 ldx PlayerRows,y
 stx.b GRP0
 sty.b RESP1
 sty.b RESP0
 sta.b GRP1
 sty.w RESP1
 ldx.b CACHE+27
 lda #14
 sta.w COLUP0
 sty.b RESP0
 stx.b GRP0
 sty.b RESP1
 lda.b CACHE+38
 sta.b GRP1
 sty.b RESP1
 lda.b CACHE+49
 sta.w GRP1
 lda #30
 bit FRAME
 sta.b COLUP0
 bit FRAME
Dynamic67Y77:
 iny
 lda.b CACHE+6
 sta.b GRP1
 lda.b CACHE+17
 ldx PlayerRows,y
 stx.b GRP0
 sty.b RESP1
 sty.b RESP0
 sta.b GRP1
 sty.w RESP1
 ldx.b CACHE+28
 lda #14
 sta.w COLUP0
 sty.b RESP0
 stx.b GRP0
 sty.b RESP1
 lda.b CACHE+39
 sta.b GRP1
 sty.b RESP1
 lda.b CACHE+50
 sta.w GRP1
 lda #30
 bit FRAME
 sta.b COLUP0
 bit FRAME
Dynamic67Y78:
 iny
 lda.b CACHE+7
 sta.b GRP1
 lda.b CACHE+18
 ldx PlayerRows,y
 stx.b GRP0
 sty.b RESP1
 sty.b RESP0
 sta.b GRP1
 sty.w RESP1
 ldx.b CACHE+29
 lda #14
 sta.w COLUP0
 sty.b RESP0
 stx.b GRP0
 sty.b RESP1
 lda.b CACHE+40
 sta.b GRP1
 sty.b RESP1
 lda.b CACHE+51
 sta.w GRP1
 lda #30
 bit FRAME
 sta.b COLUP0
 bit FRAME
Dynamic67Y79:
 iny
 lda.b CACHE+8
 sta.b GRP1
 lda.b CACHE+19
 ldx PlayerRows,y
 stx.b GRP0
 sty.b RESP1
 sty.b RESP0
 sta.b GRP1
 sty.w RESP1
 ldx.b CACHE+30
 lda #14
 sta.w COLUP0
 sty.b RESP0
 stx.b GRP0
 sty.b RESP1
 lda.b CACHE+41
 sta.b GRP1
 sty.b RESP1
 lda.b CACHE+52
 sta.w GRP1
 lda #30
 bit FRAME
 sta.b COLUP0
 bit FRAME
Dynamic67Y80:
 iny
 lda.b CACHE+9
 sta.b GRP1
 lda.b CACHE+20
 ldx PlayerRows,y
 stx.b GRP0
 sty.b RESP1
 sty.b RESP0
 sta.b GRP1
 sty.w RESP1
 ldx.b CACHE+31
 lda #14
 sta.w COLUP0
 sty.b RESP0
 stx.b GRP0
 sty.b RESP1
 lda.b CACHE+42
 sta.b GRP1
 sty.b RESP1
 lda.b CACHE+53
 sta.w GRP1
 lda #30
 bit FRAME
 sta.b COLUP0
 bit FRAME
Dynamic67Y81:
 iny
 lda.b CACHE+10
 sta.b GRP1
 lda.b CACHE+21
 ldx PlayerRows,y
 stx.b GRP0
 sty.b RESP1
 sty.b RESP0
 sta.b GRP1
 sty.w RESP1
 ldx.b CACHE+32
 lda #14
 sta.w COLUP0
 sty.b RESP0
 stx.b GRP0
 sty.b RESP1
 lda.b CACHE+43
 sta.b GRP1
 sty.b RESP1
 lda.b CACHE+54
 sta.w GRP1
 lda #30
 bit FRAME
 sta.b COLUP0
 jmp LeaveBand
Dynamic76:
 sta WSYNC
Dynamic76Y71:
 iny
 lda.b CACHE+0
 sta.b GRP1
 ldx.b CACHE+22
 lda PlayerRows,y
 sta.b GRP0
 sty.b RESP1
 sty.b RESP0
 lda.b CACHE+11
 sty.w RESP1
 sta.b GRP1
 lda #14
 stx.b GRP0
 sta.w COLUP0
 sty.b RESP0
 sty.b RESP1
 lda.b CACHE+33
 sta.b GRP1
 sty.b RESP1
 lda #30
 nop
 ldx.b CACHE+44
 stx.b GRP1
 sta.b COLUP0
 bit FRAME
 nop
Dynamic76Y72:
 iny
 lda.b CACHE+1
 sta.b GRP1
 ldx.b CACHE+23
 lda PlayerRows,y
 sta.b GRP0
 sty.b RESP1
 sty.b RESP0
 lda.b CACHE+12
 sty.w RESP1
 sta.b GRP1
 lda #14
 stx.b GRP0
 sta.w COLUP0
 sty.b RESP0
 sty.b RESP1
 lda.b CACHE+34
 sta.b GRP1
 sty.b RESP1
 lda #30
 nop
 ldx.b CACHE+45
 stx.b GRP1
 sta.b COLUP0
 bit FRAME
 nop
Dynamic76Y73:
 iny
 lda.b CACHE+2
 sta.b GRP1
 ldx.b CACHE+24
 lda PlayerRows,y
 sta.b GRP0
 sty.b RESP1
 sty.b RESP0
 lda.b CACHE+13
 sty.w RESP1
 sta.b GRP1
 lda #14
 stx.b GRP0
 sta.w COLUP0
 sty.b RESP0
 sty.b RESP1
 lda.b CACHE+35
 sta.b GRP1
 sty.b RESP1
 lda #30
 nop
 ldx.b CACHE+46
 stx.b GRP1
 sta.b COLUP0
 bit FRAME
 nop
Dynamic76Y74:
 iny
 lda.b CACHE+3
 sta.b GRP1
 ldx.b CACHE+25
 lda PlayerRows,y
 sta.b GRP0
 sty.b RESP1
 sty.b RESP0
 lda.b CACHE+14
 sty.w RESP1
 sta.b GRP1
 lda #14
 stx.b GRP0
 sta.w COLUP0
 sty.b RESP0
 sty.b RESP1
 lda.b CACHE+36
 sta.b GRP1
 sty.b RESP1
 lda #30
 nop
 ldx.b CACHE+47
 stx.b GRP1
 sta.b COLUP0
 bit FRAME
 nop
Dynamic76Y75:
 iny
 lda.b CACHE+4
 sta.b GRP1
 ldx.b CACHE+26
 lda PlayerRows,y
 sta.b GRP0
 sty.b RESP1
 sty.b RESP0
 lda.b CACHE+15
 sty.w RESP1
 sta.b GRP1
 lda #14
 stx.b GRP0
 sta.w COLUP0
 sty.b RESP0
 sty.b RESP1
 lda.b CACHE+37
 sta.b GRP1
 sty.b RESP1
 lda #30
 nop
 ldx.b CACHE+48
 stx.b GRP1
 sta.b COLUP0
 bit FRAME
 nop
Dynamic76Y76:
 iny
 lda.b CACHE+5
 sta.b GRP1
 ldx.b CACHE+27
 lda PlayerRows,y
 sta.b GRP0
 sty.b RESP1
 sty.b RESP0
 lda.b CACHE+16
 sty.w RESP1
 sta.b GRP1
 lda #14
 stx.b GRP0
 sta.w COLUP0
 sty.b RESP0
 sty.b RESP1
 lda.b CACHE+38
 sta.b GRP1
 sty.b RESP1
 lda #30
 nop
 ldx.b CACHE+49
 stx.b GRP1
 sta.b COLUP0
 bit FRAME
 nop
Dynamic76Y77:
 iny
 lda.b CACHE+6
 sta.b GRP1
 ldx.b CACHE+28
 lda PlayerRows,y
 sta.b GRP0
 sty.b RESP1
 sty.b RESP0
 lda.b CACHE+17
 sty.w RESP1
 sta.b GRP1
 lda #14
 stx.b GRP0
 sta.w COLUP0
 sty.b RESP0
 sty.b RESP1
 lda.b CACHE+39
 sta.b GRP1
 sty.b RESP1
 lda #30
 nop
 ldx.b CACHE+50
 stx.b GRP1
 sta.b COLUP0
 bit FRAME
 nop
Dynamic76Y78:
 iny
 lda.b CACHE+7
 sta.b GRP1
 ldx.b CACHE+29
 lda PlayerRows,y
 sta.b GRP0
 sty.b RESP1
 sty.b RESP0
 lda.b CACHE+18
 sty.w RESP1
 sta.b GRP1
 lda #14
 stx.b GRP0
 sta.w COLUP0
 sty.b RESP0
 sty.b RESP1
 lda.b CACHE+40
 sta.b GRP1
 sty.b RESP1
 lda #30
 nop
 ldx.b CACHE+51
 stx.b GRP1
 sta.b COLUP0
 bit FRAME
 nop
Dynamic76Y79:
 iny
 lda.b CACHE+8
 sta.b GRP1
 ldx.b CACHE+30
 lda PlayerRows,y
 sta.b GRP0
 sty.b RESP1
 sty.b RESP0
 lda.b CACHE+19
 sty.w RESP1
 sta.b GRP1
 lda #14
 stx.b GRP0
 sta.w COLUP0
 sty.b RESP0
 sty.b RESP1
 lda.b CACHE+41
 sta.b GRP1
 sty.b RESP1
 lda #30
 nop
 ldx.b CACHE+52
 stx.b GRP1
 sta.b COLUP0
 bit FRAME
 nop
Dynamic76Y80:
 iny
 lda.b CACHE+9
 sta.b GRP1
 ldx.b CACHE+31
 lda PlayerRows,y
 sta.b GRP0
 sty.b RESP1
 sty.b RESP0
 lda.b CACHE+20
 sty.w RESP1
 sta.b GRP1
 lda #14
 stx.b GRP0
 sta.w COLUP0
 sty.b RESP0
 sty.b RESP1
 lda.b CACHE+42
 sta.b GRP1
 sty.b RESP1
 lda #30
 nop
 ldx.b CACHE+53
 stx.b GRP1
 sta.b COLUP0
 bit FRAME
 nop
Dynamic76Y81:
 iny
 lda.b CACHE+10
 sta.b GRP1
 ldx.b CACHE+32
 lda PlayerRows,y
 sta.b GRP0
 sty.b RESP1
 sty.b RESP0
 lda.b CACHE+21
 sty.w RESP1
 sta.b GRP1
 lda #14
 stx.b GRP0
 sta.w COLUP0
 sty.b RESP0
 sty.b RESP1
 lda.b CACHE+43
 sta.b GRP1
 sty.b RESP1
 lda #30
 nop
 ldx.b CACHE+54
 stx.b GRP1
 sta.b COLUP0
 nop
 jmp LeaveBand
ThirdXs:
 byte 73,67,76,82
DynamicLo:
 byte <Dynamic73,<Dynamic67,<Dynamic76,0
DynamicHi:
 byte >Dynamic73,>Dynamic67,>Dynamic76,0
DynamicClocks:
 byte 1,1,1,0
 ALIGN 32
Mask0:
 ds 2,0
 byte $3c,$3c,$18,$ff,$18,$24,$24,$42,$42
 ds 2,0
 ALIGN 32
Mask1:
 ds 2,0
 byte $3c,$3c,$18,$ff,$18,$24,$24,$42,$42
 ds 2,0
 ALIGN 32
Mask2:
 ds 2,0
 byte $3c,$3c,$18,$ff,$3c,$7e,$7e,$24,$24
 ds 2,0
 ALIGN 32
Mask3:
 ds 2,0
 byte $00,$00,$3c,$3c,$18,$7e,$18,$24,$00
 ds 2,0
 ALIGN 32
Mask4:
 ds 2,0
 byte $00,$00,$3c,$3c,$18,$7e,$3c,$24,$00
 ds 2,0
MaskLo:
 byte <Mask0,<Mask1,<Mask2,<Mask3,<Mask4
MaskHi:
 byte >Mask0,>Mask1,>Mask2,>Mask3,>Mask4
