Dynamic73:
 sta WSYNC
Dynamic73Y71:
 iny
 lda PlayerRows,y
 ldx.b CACHE+0
 sta.b GRP0
 stx.w GRP1
 lda.b CACHE+22
 sty.b RESP1
 ldx.b CACHE+11
 bit FRAME
 sty.b RESP1
 stx.b GRP1
 ldx.b CACHE+33
 sty.b RESP1
 sta.b GRP1
 lda.b CACHE+44
 sty.b RESP1
 nop
 stx.w GRP1
 sty.b RESP1
 sta.w GRP1
 nop
 nop
 nop
 nop
 nop
 nop
 nop
Dynamic73Y72:
 iny
 lda PlayerRows,y
 ldx.b CACHE+1
 sta.b GRP0
 stx.w GRP1
 lda.b CACHE+23
 sty.b RESP1
 ldx.b CACHE+12
 bit FRAME
 sty.b RESP1
 stx.b GRP1
 ldx.b CACHE+34
 sty.b RESP1
 sta.b GRP1
 lda.b CACHE+45
 sty.b RESP1
 nop
 stx.w GRP1
 sty.b RESP1
 sta.w GRP1
 nop
 nop
 nop
 nop
 nop
 nop
 nop
Dynamic73Y73:
 iny
 lda PlayerRows,y
 ldx.b CACHE+2
 sta.b GRP0
 stx.w GRP1
 lda.b CACHE+24
 sty.b RESP1
 ldx.b CACHE+13
 bit FRAME
 sty.b RESP1
 stx.b GRP1
 ldx.b CACHE+35
 sty.b RESP1
 sta.b GRP1
 lda.b CACHE+46
 sty.b RESP1
 nop
 stx.w GRP1
 sty.b RESP1
 sta.w GRP1
 nop
 nop
 nop
 nop
 nop
 nop
 nop
Dynamic73Y74:
 iny
 lda PlayerRows,y
 ldx.b CACHE+3
 sta.b GRP0
 stx.w GRP1
 lda.b CACHE+25
 sty.b RESP1
 ldx.b CACHE+14
 bit FRAME
 sty.b RESP1
 stx.b GRP1
 ldx.b CACHE+36
 sty.b RESP1
 sta.b GRP1
 lda.b CACHE+47
 sty.b RESP1
 nop
 stx.w GRP1
 sty.b RESP1
 sta.w GRP1
 nop
 nop
 nop
 nop
 nop
 nop
 nop
Dynamic73Y75:
 iny
 lda PlayerRows,y
 ldx.b CACHE+4
 sta.b GRP0
 stx.w GRP1
 lda.b CACHE+26
 sty.b RESP1
 ldx.b CACHE+15
 bit FRAME
 sty.b RESP1
 stx.b GRP1
 ldx.b CACHE+37
 sty.b RESP1
 sta.b GRP1
 lda.b CACHE+48
 sty.b RESP1
 nop
 stx.w GRP1
 sty.b RESP1
 sta.w GRP1
 nop
 nop
 nop
 nop
 nop
 nop
 nop
Dynamic73Y76:
 iny
 lda PlayerRows,y
 ldx.b CACHE+5
 sta.b GRP0
 stx.w GRP1
 lda.b CACHE+27
 sty.b RESP1
 ldx.b CACHE+16
 bit FRAME
 sty.b RESP1
 stx.b GRP1
 ldx.b CACHE+38
 sty.b RESP1
 sta.b GRP1
 lda.b CACHE+49
 sty.b RESP1
 nop
 stx.w GRP1
 sty.b RESP1
 sta.w GRP1
 nop
 nop
 nop
 nop
 nop
 nop
 nop
Dynamic73Y77:
 iny
 lda PlayerRows,y
 ldx.b CACHE+6
 sta.b GRP0
 stx.w GRP1
 lda.b CACHE+28
 sty.b RESP1
 ldx.b CACHE+17
 bit FRAME
 sty.b RESP1
 stx.b GRP1
 ldx.b CACHE+39
 sty.b RESP1
 sta.b GRP1
 lda.b CACHE+50
 sty.b RESP1
 nop
 stx.w GRP1
 sty.b RESP1
 sta.w GRP1
 nop
 nop
 nop
 nop
 nop
 nop
 nop
Dynamic73Y78:
 iny
 lda PlayerRows,y
 ldx.b CACHE+7
 sta.b GRP0
 stx.w GRP1
 lda.b CACHE+29
 sty.b RESP1
 ldx.b CACHE+18
 bit FRAME
 sty.b RESP1
 stx.b GRP1
 ldx.b CACHE+40
 sty.b RESP1
 sta.b GRP1
 lda.b CACHE+51
 sty.b RESP1
 nop
 stx.w GRP1
 sty.b RESP1
 sta.w GRP1
 nop
 nop
 nop
 nop
 nop
 nop
 nop
Dynamic73Y79:
 iny
 lda PlayerRows,y
 ldx.b CACHE+8
 sta.b GRP0
 stx.w GRP1
 lda.b CACHE+30
 sty.b RESP1
 ldx.b CACHE+19
 bit FRAME
 sty.b RESP1
 stx.b GRP1
 ldx.b CACHE+41
 sty.b RESP1
 sta.b GRP1
 lda.b CACHE+52
 sty.b RESP1
 nop
 stx.w GRP1
 sty.b RESP1
 sta.w GRP1
 nop
 nop
 nop
 nop
 nop
 nop
 nop
Dynamic73Y80:
 iny
 lda PlayerRows,y
 ldx.b CACHE+9
 sta.b GRP0
 stx.w GRP1
 lda.b CACHE+31
 sty.b RESP1
 ldx.b CACHE+20
 bit FRAME
 sty.b RESP1
 stx.b GRP1
 ldx.b CACHE+42
 sty.b RESP1
 sta.b GRP1
 lda.b CACHE+53
 sty.b RESP1
 nop
 stx.w GRP1
 sty.b RESP1
 sta.w GRP1
 nop
 nop
 nop
 nop
 nop
 nop
 nop
Dynamic73Y81:
 iny
 lda PlayerRows,y
 ldx.b CACHE+10
 sta.b GRP0
 stx.w GRP1
 lda.b CACHE+32
 sty.b RESP1
 ldx.b CACHE+21
 bit FRAME
 sty.b RESP1
 stx.b GRP1
 ldx.b CACHE+43
 sty.b RESP1
 sta.b GRP1
 lda.b CACHE+54
 sty.b RESP1
 nop
 stx.w GRP1
 sty.b RESP1
 sta.w GRP1
 bit FRAME
 nop
 nop
 nop
 nop
 jmp LeaveBand
Dynamic67:
 sta WSYNC
Dynamic67Y71:
 iny
 lda PlayerRows,y
 sta.b GRP0
 ldx.b CACHE+0
 lda.b CACHE+22
 stx.b GRP1
 sty.w RESP1
 ldx.b CACHE+11
 bit FRAME
 sty.b RESP1
 stx.b GRP1
 sty.w RESP1
 nop
 sta.b GRP1
 lda.b CACHE+33
 sty.b RESP1
 sta.w GRP1
 nop
 sty.b RESP1
 lda.b CACHE+44
 sta.b GRP1
 nop
 nop
 nop
 nop
 nop
 nop
Dynamic67Y72:
 iny
 lda PlayerRows,y
 sta.b GRP0
 ldx.b CACHE+1
 lda.b CACHE+23
 stx.b GRP1
 sty.w RESP1
 ldx.b CACHE+12
 bit FRAME
 sty.b RESP1
 stx.b GRP1
 sty.w RESP1
 nop
 sta.b GRP1
 lda.b CACHE+34
 sty.b RESP1
 sta.w GRP1
 nop
 sty.b RESP1
 lda.b CACHE+45
 sta.b GRP1
 nop
 nop
 nop
 nop
 nop
 nop
Dynamic67Y73:
 iny
 lda PlayerRows,y
 sta.b GRP0
 ldx.b CACHE+2
 lda.b CACHE+24
 stx.b GRP1
 sty.w RESP1
 ldx.b CACHE+13
 bit FRAME
 sty.b RESP1
 stx.b GRP1
 sty.w RESP1
 nop
 sta.b GRP1
 lda.b CACHE+35
 sty.b RESP1
 sta.w GRP1
 nop
 sty.b RESP1
 lda.b CACHE+46
 sta.b GRP1
 nop
 nop
 nop
 nop
 nop
 nop
Dynamic67Y74:
 iny
 lda PlayerRows,y
 sta.b GRP0
 ldx.b CACHE+3
 lda.b CACHE+25
 stx.b GRP1
 sty.w RESP1
 ldx.b CACHE+14
 bit FRAME
 sty.b RESP1
 stx.b GRP1
 sty.w RESP1
 nop
 sta.b GRP1
 lda.b CACHE+36
 sty.b RESP1
 sta.w GRP1
 nop
 sty.b RESP1
 lda.b CACHE+47
 sta.b GRP1
 nop
 nop
 nop
 nop
 nop
 nop
Dynamic67Y75:
 iny
 lda PlayerRows,y
 sta.b GRP0
 ldx.b CACHE+4
 lda.b CACHE+26
 stx.b GRP1
 sty.w RESP1
 ldx.b CACHE+15
 bit FRAME
 sty.b RESP1
 stx.b GRP1
 sty.w RESP1
 nop
 sta.b GRP1
 lda.b CACHE+37
 sty.b RESP1
 sta.w GRP1
 nop
 sty.b RESP1
 lda.b CACHE+48
 sta.b GRP1
 nop
 nop
 nop
 nop
 nop
 nop
Dynamic67Y76:
 iny
 lda PlayerRows,y
 sta.b GRP0
 ldx.b CACHE+5
 lda.b CACHE+27
 stx.b GRP1
 sty.w RESP1
 ldx.b CACHE+16
 bit FRAME
 sty.b RESP1
 stx.b GRP1
 sty.w RESP1
 nop
 sta.b GRP1
 lda.b CACHE+38
 sty.b RESP1
 sta.w GRP1
 nop
 sty.b RESP1
 lda.b CACHE+49
 sta.b GRP1
 nop
 nop
 nop
 nop
 nop
 nop
Dynamic67Y77:
 iny
 lda PlayerRows,y
 sta.b GRP0
 ldx.b CACHE+6
 lda.b CACHE+28
 stx.b GRP1
 sty.w RESP1
 ldx.b CACHE+17
 bit FRAME
 sty.b RESP1
 stx.b GRP1
 sty.w RESP1
 nop
 sta.b GRP1
 lda.b CACHE+39
 sty.b RESP1
 sta.w GRP1
 nop
 sty.b RESP1
 lda.b CACHE+50
 sta.b GRP1
 nop
 nop
 nop
 nop
 nop
 nop
Dynamic67Y78:
 iny
 lda PlayerRows,y
 sta.b GRP0
 ldx.b CACHE+7
 lda.b CACHE+29
 stx.b GRP1
 sty.w RESP1
 ldx.b CACHE+18
 bit FRAME
 sty.b RESP1
 stx.b GRP1
 sty.w RESP1
 nop
 sta.b GRP1
 lda.b CACHE+40
 sty.b RESP1
 sta.w GRP1
 nop
 sty.b RESP1
 lda.b CACHE+51
 sta.b GRP1
 nop
 nop
 nop
 nop
 nop
 nop
Dynamic67Y79:
 iny
 lda PlayerRows,y
 sta.b GRP0
 ldx.b CACHE+8
 lda.b CACHE+30
 stx.b GRP1
 sty.w RESP1
 ldx.b CACHE+19
 bit FRAME
 sty.b RESP1
 stx.b GRP1
 sty.w RESP1
 nop
 sta.b GRP1
 lda.b CACHE+41
 sty.b RESP1
 sta.w GRP1
 nop
 sty.b RESP1
 lda.b CACHE+52
 sta.b GRP1
 nop
 nop
 nop
 nop
 nop
 nop
Dynamic67Y80:
 iny
 lda PlayerRows,y
 sta.b GRP0
 ldx.b CACHE+9
 lda.b CACHE+31
 stx.b GRP1
 sty.w RESP1
 ldx.b CACHE+20
 bit FRAME
 sty.b RESP1
 stx.b GRP1
 sty.w RESP1
 nop
 sta.b GRP1
 lda.b CACHE+42
 sty.b RESP1
 sta.w GRP1
 nop
 sty.b RESP1
 lda.b CACHE+53
 sta.b GRP1
 nop
 nop
 nop
 nop
 nop
 nop
Dynamic67Y81:
 iny
 lda PlayerRows,y
 sta.b GRP0
 ldx.b CACHE+10
 lda.b CACHE+32
 stx.b GRP1
 sty.w RESP1
 ldx.b CACHE+21
 bit FRAME
 sty.b RESP1
 stx.b GRP1
 sty.w RESP1
 nop
 sta.b GRP1
 lda.b CACHE+43
 sty.b RESP1
 sta.w GRP1
 nop
 sty.b RESP1
 lda.b CACHE+54
 sta.b GRP1
 bit FRAME
 nop
 nop
 nop
 jmp LeaveBand
Dynamic76:
 sta WSYNC
Dynamic76Y71:
 iny
 lda.b CACHE+0
 ldx.b CACHE+22
 sta.w GRP1
 lda PlayerRows,y
 sta.b GRP0
 sty.b RESP1
 lda.b CACHE+11
 bit FRAME
 sty.b RESP1
 sta.b GRP1
 stx.b GRP1
 sty.w RESP1
 lda.b CACHE+33
 nop
 sty.b RESP1
 sta.b GRP1
 nop
 sty.w RESP1
 ldx.b CACHE+44
 stx.b GRP1
 nop
 nop
 nop
 nop
 nop
 nop
Dynamic76Y72:
 iny
 lda.b CACHE+1
 ldx.b CACHE+23
 sta.w GRP1
 lda PlayerRows,y
 sta.b GRP0
 sty.b RESP1
 lda.b CACHE+12
 bit FRAME
 sty.b RESP1
 sta.b GRP1
 stx.b GRP1
 sty.w RESP1
 lda.b CACHE+34
 nop
 sty.b RESP1
 sta.b GRP1
 nop
 sty.w RESP1
 ldx.b CACHE+45
 stx.b GRP1
 nop
 nop
 nop
 nop
 nop
 nop
Dynamic76Y73:
 iny
 lda.b CACHE+2
 ldx.b CACHE+24
 sta.w GRP1
 lda PlayerRows,y
 sta.b GRP0
 sty.b RESP1
 lda.b CACHE+13
 bit FRAME
 sty.b RESP1
 sta.b GRP1
 stx.b GRP1
 sty.w RESP1
 lda.b CACHE+35
 nop
 sty.b RESP1
 sta.b GRP1
 nop
 sty.w RESP1
 ldx.b CACHE+46
 stx.b GRP1
 nop
 nop
 nop
 nop
 nop
 nop
Dynamic76Y74:
 iny
 lda.b CACHE+3
 ldx.b CACHE+25
 sta.w GRP1
 lda PlayerRows,y
 sta.b GRP0
 sty.b RESP1
 lda.b CACHE+14
 bit FRAME
 sty.b RESP1
 sta.b GRP1
 stx.b GRP1
 sty.w RESP1
 lda.b CACHE+36
 nop
 sty.b RESP1
 sta.b GRP1
 nop
 sty.w RESP1
 ldx.b CACHE+47
 stx.b GRP1
 nop
 nop
 nop
 nop
 nop
 nop
Dynamic76Y75:
 iny
 lda.b CACHE+4
 ldx.b CACHE+26
 sta.w GRP1
 lda PlayerRows,y
 sta.b GRP0
 sty.b RESP1
 lda.b CACHE+15
 bit FRAME
 sty.b RESP1
 sta.b GRP1
 stx.b GRP1
 sty.w RESP1
 lda.b CACHE+37
 nop
 sty.b RESP1
 sta.b GRP1
 nop
 sty.w RESP1
 ldx.b CACHE+48
 stx.b GRP1
 nop
 nop
 nop
 nop
 nop
 nop
Dynamic76Y76:
 iny
 lda.b CACHE+5
 ldx.b CACHE+27
 sta.w GRP1
 lda PlayerRows,y
 sta.b GRP0
 sty.b RESP1
 lda.b CACHE+16
 bit FRAME
 sty.b RESP1
 sta.b GRP1
 stx.b GRP1
 sty.w RESP1
 lda.b CACHE+38
 nop
 sty.b RESP1
 sta.b GRP1
 nop
 sty.w RESP1
 ldx.b CACHE+49
 stx.b GRP1
 nop
 nop
 nop
 nop
 nop
 nop
Dynamic76Y77:
 iny
 lda.b CACHE+6
 ldx.b CACHE+28
 sta.w GRP1
 lda PlayerRows,y
 sta.b GRP0
 sty.b RESP1
 lda.b CACHE+17
 bit FRAME
 sty.b RESP1
 sta.b GRP1
 stx.b GRP1
 sty.w RESP1
 lda.b CACHE+39
 nop
 sty.b RESP1
 sta.b GRP1
 nop
 sty.w RESP1
 ldx.b CACHE+50
 stx.b GRP1
 nop
 nop
 nop
 nop
 nop
 nop
Dynamic76Y78:
 iny
 lda.b CACHE+7
 ldx.b CACHE+29
 sta.w GRP1
 lda PlayerRows,y
 sta.b GRP0
 sty.b RESP1
 lda.b CACHE+18
 bit FRAME
 sty.b RESP1
 sta.b GRP1
 stx.b GRP1
 sty.w RESP1
 lda.b CACHE+40
 nop
 sty.b RESP1
 sta.b GRP1
 nop
 sty.w RESP1
 ldx.b CACHE+51
 stx.b GRP1
 nop
 nop
 nop
 nop
 nop
 nop
Dynamic76Y79:
 iny
 lda.b CACHE+8
 ldx.b CACHE+30
 sta.w GRP1
 lda PlayerRows,y
 sta.b GRP0
 sty.b RESP1
 lda.b CACHE+19
 bit FRAME
 sty.b RESP1
 sta.b GRP1
 stx.b GRP1
 sty.w RESP1
 lda.b CACHE+41
 nop
 sty.b RESP1
 sta.b GRP1
 nop
 sty.w RESP1
 ldx.b CACHE+52
 stx.b GRP1
 nop
 nop
 nop
 nop
 nop
 nop
Dynamic76Y80:
 iny
 lda.b CACHE+9
 ldx.b CACHE+31
 sta.w GRP1
 lda PlayerRows,y
 sta.b GRP0
 sty.b RESP1
 lda.b CACHE+20
 bit FRAME
 sty.b RESP1
 sta.b GRP1
 stx.b GRP1
 sty.w RESP1
 lda.b CACHE+42
 nop
 sty.b RESP1
 sta.b GRP1
 nop
 sty.w RESP1
 ldx.b CACHE+53
 stx.b GRP1
 nop
 nop
 nop
 nop
 nop
 nop
Dynamic76Y81:
 iny
 lda.b CACHE+10
 ldx.b CACHE+32
 sta.w GRP1
 lda PlayerRows,y
 sta.b GRP0
 sty.b RESP1
 lda.b CACHE+21
 bit FRAME
 sty.b RESP1
 sta.b GRP1
 stx.b GRP1
 sty.w RESP1
 lda.b CACHE+43
 nop
 sty.b RESP1
 sta.b GRP1
 nop
 sty.w RESP1
 ldx.b CACHE+54
 stx.b GRP1
 bit FRAME
 nop
 nop
 nop
 jmp LeaveBand
Dynamic82:
 sta WSYNC
Dynamic82Y71:
 iny
 lda PlayerRows,y
 sta.w GRP0
 bit FRAME
 ldx.b CACHE+0
 lda.b CACHE+44
 sty.b RESP1
 stx.b GRP1
 ldx.b CACHE+11
 sty.b RESP1
 stx.b GRP1
 ldx.b CACHE+22
 stx.b GRP1
 sty.b RESP1
 nop
 sty.w RESP1
 ldx.b CACHE+33
 stx.b GRP1
 sty.b RESP1
 nop
 sta.b GRP1
 bit FRAME
 nop
 nop
 nop
 nop
 nop
Dynamic82Y72:
 iny
 lda PlayerRows,y
 sta.w GRP0
 bit FRAME
 ldx.b CACHE+1
 lda.b CACHE+45
 sty.b RESP1
 stx.b GRP1
 ldx.b CACHE+12
 sty.b RESP1
 stx.b GRP1
 ldx.b CACHE+23
 stx.b GRP1
 sty.b RESP1
 nop
 sty.w RESP1
 ldx.b CACHE+34
 stx.b GRP1
 sty.b RESP1
 nop
 sta.b GRP1
 bit FRAME
 nop
 nop
 nop
 nop
 nop
Dynamic82Y73:
 iny
 lda PlayerRows,y
 sta.w GRP0
 bit FRAME
 ldx.b CACHE+2
 lda.b CACHE+46
 sty.b RESP1
 stx.b GRP1
 ldx.b CACHE+13
 sty.b RESP1
 stx.b GRP1
 ldx.b CACHE+24
 stx.b GRP1
 sty.b RESP1
 nop
 sty.w RESP1
 ldx.b CACHE+35
 stx.b GRP1
 sty.b RESP1
 nop
 sta.b GRP1
 bit FRAME
 nop
 nop
 nop
 nop
 nop
Dynamic82Y74:
 iny
 lda PlayerRows,y
 sta.w GRP0
 bit FRAME
 ldx.b CACHE+3
 lda.b CACHE+47
 sty.b RESP1
 stx.b GRP1
 ldx.b CACHE+14
 sty.b RESP1
 stx.b GRP1
 ldx.b CACHE+25
 stx.b GRP1
 sty.b RESP1
 nop
 sty.w RESP1
 ldx.b CACHE+36
 stx.b GRP1
 sty.b RESP1
 nop
 sta.b GRP1
 bit FRAME
 nop
 nop
 nop
 nop
 nop
Dynamic82Y75:
 iny
 lda PlayerRows,y
 sta.w GRP0
 bit FRAME
 ldx.b CACHE+4
 lda.b CACHE+48
 sty.b RESP1
 stx.b GRP1
 ldx.b CACHE+15
 sty.b RESP1
 stx.b GRP1
 ldx.b CACHE+26
 stx.b GRP1
 sty.b RESP1
 nop
 sty.w RESP1
 ldx.b CACHE+37
 stx.b GRP1
 sty.b RESP1
 nop
 sta.b GRP1
 bit FRAME
 nop
 nop
 nop
 nop
 nop
Dynamic82Y76:
 iny
 lda PlayerRows,y
 sta.w GRP0
 bit FRAME
 ldx.b CACHE+5
 lda.b CACHE+49
 sty.b RESP1
 stx.b GRP1
 ldx.b CACHE+16
 sty.b RESP1
 stx.b GRP1
 ldx.b CACHE+27
 stx.b GRP1
 sty.b RESP1
 nop
 sty.w RESP1
 ldx.b CACHE+38
 stx.b GRP1
 sty.b RESP1
 nop
 sta.b GRP1
 bit FRAME
 nop
 nop
 nop
 nop
 nop
Dynamic82Y77:
 iny
 lda PlayerRows,y
 sta.w GRP0
 bit FRAME
 ldx.b CACHE+6
 lda.b CACHE+50
 sty.b RESP1
 stx.b GRP1
 ldx.b CACHE+17
 sty.b RESP1
 stx.b GRP1
 ldx.b CACHE+28
 stx.b GRP1
 sty.b RESP1
 nop
 sty.w RESP1
 ldx.b CACHE+39
 stx.b GRP1
 sty.b RESP1
 nop
 sta.b GRP1
 bit FRAME
 nop
 nop
 nop
 nop
 nop
Dynamic82Y78:
 iny
 lda PlayerRows,y
 sta.w GRP0
 bit FRAME
 ldx.b CACHE+7
 lda.b CACHE+51
 sty.b RESP1
 stx.b GRP1
 ldx.b CACHE+18
 sty.b RESP1
 stx.b GRP1
 ldx.b CACHE+29
 stx.b GRP1
 sty.b RESP1
 nop
 sty.w RESP1
 ldx.b CACHE+40
 stx.b GRP1
 sty.b RESP1
 nop
 sta.b GRP1
 bit FRAME
 nop
 nop
 nop
 nop
 nop
Dynamic82Y79:
 iny
 lda PlayerRows,y
 sta.w GRP0
 bit FRAME
 ldx.b CACHE+8
 lda.b CACHE+52
 sty.b RESP1
 stx.b GRP1
 ldx.b CACHE+19
 sty.b RESP1
 stx.b GRP1
 ldx.b CACHE+30
 stx.b GRP1
 sty.b RESP1
 nop
 sty.w RESP1
 ldx.b CACHE+41
 stx.b GRP1
 sty.b RESP1
 nop
 sta.b GRP1
 bit FRAME
 nop
 nop
 nop
 nop
 nop
Dynamic82Y80:
 iny
 lda PlayerRows,y
 sta.w GRP0
 bit FRAME
 ldx.b CACHE+9
 lda.b CACHE+53
 sty.b RESP1
 stx.b GRP1
 ldx.b CACHE+20
 sty.b RESP1
 stx.b GRP1
 ldx.b CACHE+31
 stx.b GRP1
 sty.b RESP1
 nop
 sty.w RESP1
 ldx.b CACHE+42
 stx.b GRP1
 sty.b RESP1
 nop
 sta.b GRP1
 bit FRAME
 nop
 nop
 nop
 nop
 nop
Dynamic82Y81:
 iny
 lda PlayerRows,y
 sta.w GRP0
 bit FRAME
 ldx.b CACHE+10
 lda.b CACHE+54
 sty.b RESP1
 stx.b GRP1
 ldx.b CACHE+21
 sty.b RESP1
 stx.b GRP1
 ldx.b CACHE+32
 stx.b GRP1
 sty.b RESP1
 nop
 sty.w RESP1
 ldx.b CACHE+43
 stx.b GRP1
 sty.b RESP1
 nop
 sta.b GRP1
 nop
 nop
 nop
 nop
 nop
 jmp LeaveBand
ThirdXs:
 byte 73,67,76,82
DynamicLo:
 byte <Dynamic73,<Dynamic67,<Dynamic76,<Dynamic82
DynamicHi:
 byte >Dynamic73,>Dynamic67,>Dynamic76,>Dynamic82
DynamicClocks:
 byte 1,1,1,1
 ALIGN 32
Mask0:
 ds 2,0
 byte $3c,$3c,$18,$ff,$18,$24,$24,$42,$42
 ds 2,0
 ALIGN 32
Mask1:
 ds 2,0
 byte $3c,$3c,$18,$ff,$18,$24,$24,$42,$42
 ds 2,0
 ALIGN 32
Mask2:
 ds 2,0
 byte $3c,$3c,$18,$ff,$3c,$7e,$7e,$24,$24
 ds 2,0
 ALIGN 32
Mask3:
 ds 2,0
 byte $00,$00,$3c,$3c,$18,$7e,$18,$24,$00
 ds 2,0
 ALIGN 32
Mask4:
 ds 2,0
 byte $00,$00,$3c,$3c,$18,$7e,$3c,$24,$00
 ds 2,0
MaskLo:
 byte <Mask0,<Mask1,<Mask2,<Mask3,<Mask4
MaskHi:
 byte >Mask0,>Mask1,>Mask2,>Mask3,>Mask4
