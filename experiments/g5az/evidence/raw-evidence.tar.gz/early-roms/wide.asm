ACTORS=5
ROTATING=0
UNION_ENABLED=0
 include "kernel.asm"
