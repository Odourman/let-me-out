ACTORS=5
ROTATING=0
UNION_ENABLED=1
 include "kernel.asm"
