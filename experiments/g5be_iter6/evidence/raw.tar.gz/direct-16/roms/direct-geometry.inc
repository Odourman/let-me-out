FIRST_MIN=16
FIRST_SPAN=10
FirstBank:
 byte 1,$ff,$ff,0,$ff,$ff,2,$ff,$ff,3
SecondX:
 byte 46,46,46,46
FourthX:
 byte 100,100,100,100
RightX:
 byte 127,127,127,127
