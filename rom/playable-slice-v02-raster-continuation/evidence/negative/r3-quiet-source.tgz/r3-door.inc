ParkR3Door:
 lda DoorColor
 sta COLUP1
 ldx #14
 sta WSYNC
R3DoorDelay:
 dex
 bne R3DoorDelay
 sta RESP1
 sta WSYNC
 rts
R3DoorStart:
 ds 12,$3c
 ds 4,$66
 ds 4,$76
 ds 12,$3c
