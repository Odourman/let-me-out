EmptyR3Queue:
 lda #<(PlayerShape-255)
 sta P1Ptr
 lda #>(PlayerShape-255)
 sta P1Ptr+1
 rts
