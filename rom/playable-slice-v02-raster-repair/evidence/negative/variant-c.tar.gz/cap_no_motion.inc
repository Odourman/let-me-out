CapNoMotion:
 sec
CapNoMotionCoarse:
 sbc #15
 bcs CapNoMotionCoarse
 eor #15
 asl
 asl
 asl
 asl
 sta HMP1
 sta RESP1
 jmp CapLateDelay
