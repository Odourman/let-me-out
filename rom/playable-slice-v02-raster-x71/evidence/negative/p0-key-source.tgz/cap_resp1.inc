CapPositionSF:
 clc
 eor #15
 sbc #0
 nop
 asl
 asl
 asl
 asl
 sta HMP1
CapSFReset:
 sta RESP1
 jmp CapLateDelay
