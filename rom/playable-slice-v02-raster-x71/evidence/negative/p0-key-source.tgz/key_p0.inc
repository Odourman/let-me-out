WideCopy:
 lda #4
 sta NUSIZ0
 rts

GoldCopyLine:
 lda #$1e
 sta COLUP0
 lda (P0Ptr),y
 sta GRP0
 lda (P1Ptr),y
 sta GRP1
 cpy #239
 beq GoldCopyEnd
 lda #$1a
 sta COLUP0
 lda GoldCopyRows-234,y
 sta GRP0
 jmp RoomTail
GoldCopyEnd:
 lda #0
 sta NUSIZ0
 jmp RoomTail
GoldCopyRows:
 byte $70,$50,$7e,$24,$04
