DoorBitmap:
 ds 12,$3c
 ds 4,$66
 ds 4,$76
 ds 12,$3c
