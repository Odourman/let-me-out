ProbeParkM0:
 lda #155
 ldx #2
 jmp Position

ProbeDoorHole:
 lda (P1Ptr),y
 sta GRP1
 lda #0
 sta COLUP0
 cpy #168
 bcs ProbeDoorStem
 lda #$10
ProbeDoorStem:
 sta $04              ; NUSIZ0, only the M0 width bits
 lda DoorColor
 sta COLUPF
 beq ProbeDoorOff
 cpy #172
 bcs ProbeDoorOff
 lda #2
 sta ENAM0
 iny
 jmp RoomQueueCheck
ProbeDoorOff:
 lda #0
 sta ENAM0
 lda #$1e
 sta COLUP0
 iny
 jmp RoomQueueCheck
