CacheCapPlayer:
 ldy CapStart
 iny
 iny
 lda (P0Ptr),y
 sta CapPlayerFirst
 iny
 lda (P0Ptr),y
 sta CapPlayerNext
 rts
