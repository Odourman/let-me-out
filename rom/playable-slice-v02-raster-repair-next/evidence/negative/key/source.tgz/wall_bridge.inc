; One scheduled P1 setup can reuse the late-HMOVE kernel with M1 disabled.
; Restrict it to the calibrated X63–70 domain within the flat door-band PF.
PlanWallBridge:
 lda CapStart
 ora Shot
 ora KeyState
 ora Unlocked
 bne RejectWallBridge
 lda Eligible
 cmp Rendered
 bne RejectWallBridge
 ldx SortI
 dex
NextWallSlot:
 bmi RejectWallBridge
 lda QueueY,x
 cmp #155
 bcc PreviousWallSlot
 cmp #181
 bcs PreviousWallSlot
 lda QueueX,x
 sec
 sbc #66
 cmp #8
 bcs PreviousWallSlot
 clc
 adc #7
 sta BridgeX
 lda #0              ; the vertical sorter leaves no previous mask on this row
 sta BridgeOld
 sta QueueX,x
 lda QueueY,x
 sec
 sbc #2
 sta CapStart
RejectWallBridge:
 rts
PreviousWallSlot:
 dex
 jmp NextWallSlot

CapRasterLine:
 ldx CapStart
 beq StoreRasterShot
 ldx BridgeX
 cpx #7
 bcs StoreRasterShot
 ora CapStart
StoreRasterShot:
 rts
