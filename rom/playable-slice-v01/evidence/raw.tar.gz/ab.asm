 processor 6502
VSYNC=$00
VBLANK=$01
WSYNC=$02
NUSIZ0=$04
NUSIZ1=$05
COLUP0=$06
COLUP1=$07
COLUPF=$08
COLUBK=$09
CTRLPF=$0a
PF0=$0d
PF1=$0e
PF2=$0f
RESP0=$10
GRP0=$1b
GRP1=$1c
ENAM0=$1d
HMP0=$20
HMOVE=$2a
HMCLR=$2b
INPT4=$0c
SWCHA=$0280
SWCHB=$0282
INTIM=$0284
TIM64T=$0296

PX=$80
PY=$81
Aim=$82
Pressed=$83
Shot=$84
BX=$85
BY=$86
Direction=$87
Hunt=$88
P0Ptr=$89
BLine=$8b
TX=$8c
TY=$8d
Tmp=$8e
Tile=$8f
FrameClock=$90

 ORG $f000
Reset:
 sei
 cld
 ldx #$ff
 txs
 lda #0
 ldx #127
ClearRam:
 sta $80,x
 dex
 bpl ClearRam
 ldx #$2c
ClearTIA:
 sta 0,x
 dex
 bpl ClearTIA
 lda #12
 sta PX
 lda #82
 sta PY
 lda #8                    ; right, when the stick is neutral
 sta Aim
 lda #1
 sta CTRLPF
 lda #$1e
 sta COLUP0
 lda #$0e
 sta COLUP1
 lda #$26
 sta COLUPF
Frame:
 lda #2
 sta WSYNC
 sta VBLANK
 sta VSYNC
 sta WSYNC
 sta WSYNC
 sta WSYNC
 lda #0
 sta VSYNC
 lda #44
 sta TIM64T
 ; Horizontal setup uses P0 and M0's independent reset/fine-motion registers.
 lda PX
 ldx #0
 jsr Position
 lda BX
 ldx #2
 jsr Position
 sta WSYNC
 sta HMOVE
 sta WSYNC
 sta HMCLR

 sec
 lda #<PlayerShape
 sbc PY
 sta P0Ptr
 lda #>PlayerShape
 sbc #0
 sta P0Ptr+1
 ldx #255
 lda Shot
 beq NoRasterShot
 ldx BY
NoRasterShot:
 stx BLine
 lda #0
 sta PF0
 sta PF1
 sta PF2
 sta GRP0
 sta ENAM0
BlankWait:
 lda INTIM
 bne BlankWait
 sta WSYNC
 sta VBLANK
 ldx #8
Top:
 sta WSYNC
 dex
 bne Top
 ldy #0
Room:
 lda PFData0,y
 sta PF0
 lda PFData1,y
 sta PF1
 lda PFData2,y
 sta PF2
 lda (P0Ptr),y
 sta GRP0
 lda #0
 cpy BLine
 bne MissileOff
 lda #2
MissileOff:
 sta ENAM0
 iny
 cpy #176
 sta WSYNC
 bne Room
 lda #0
 sta PF0
 sta PF1
 sta PF2
 sta GRP0
 sta ENAM0
 ldx #8
Bottom:
 sta WSYNC
 dex
 bne Bottom
 lda #2
 sta VBLANK
 lda #35
 sta TIM64T
 inc FrameClock
 jsr Gameplay
Overscan:
 lda INTIM
 bne Overscan
 jmp Frame

; A is pixel X, X is 0 for P0 and 2 for M0.
Position:
 sta WSYNC
 sec
PositionCoarse:
 sbc #15
 bcs PositionCoarse
 eor #7
 asl
 asl
 asl
 asl
 sta HMP0,x
 sta RESP0,x
 rts

Gameplay:
 ; Convert active-low direction to R L D U bits.
 lda SWCHA
 eor #$ff
 lsr
 lsr
 lsr
 lsr
 tax
 lda Dx,x
 ora Dy,x
 beq KeepAim
 stx Aim
KeepAim:
 lda INPT4
 bmi Released
 lda Pressed
 bne StepShot
 inc Pressed
 lda Shot
 bne StepShot
 inc Shot
 lda #1
 sta Hunt
 lda Aim
 sta Direction
 lda PX
 clc
 adc #3
 sta BX
 lda PY
 clc
 adc #4
 sta BY
 jmp StepShot
Released:
 lda #0
 sta Pressed
 stx Tmp
 lda Dx,x
 beq MoveY
 clc
 adc PX
 sta TX
 lda PY
 sta TY
 jsr HitBox
 bcs MoveY
 lda TX
 sta PX
MoveY:
 ldx Tmp
 lda Dy,x
 beq StepShot
 clc
 adc PY
 sta TY
 lda PX
 sta TX
 jsr HitBox
 bcs StepShot
 lda TY
 sta PY
StepShot:
 lda Shot
 beq DoneGameplay
 ldx Direction
 lda BX
 clc
 adc Dx,x
 sta BX
 lda BY
 clc
 adc Dy,x
 sta BY
 tay
 lda BX
 jsr HitPoint
 bcc DoneGameplay
 lda #0
 sta Shot
DoneGameplay:
 rts

; Six points cover the 8x9 box in this 4x8 tile grid.
HitBox:
 ldy TY
 jsr HitEdge
 bcs BoxDone
 lda TY
 clc
 adc #8
 tay
HitEdge:
 lda TX
 jsr HitPoint
 bcs BoxDone
 lda TX
 clc
 adc #4
 jsr HitPoint
 bcs BoxDone
 lda TX
 clc
 adc #7
 jmp HitPoint
BoxDone:
 rts

; A=x, Y=y. Carry indicates solid. Preserve Y.
HitPoint:
 cmp #160
 bcs Wall
 cpy #176
 bcs Wall
 tax
 lda ColumnByte,x
 clc
 adc RowOffset,y
 sta Tile
 lda ColumnMask,x
 ldx Tile
 and Collision,x
 beq Open
Wall:
 sec
 rts
Open:
 clc
 rts

Dx:
 byte 0,0,0,0,255,255,255,255,1,1,1,1,0,0,0,0
Dy:
 byte 0,255,1,0,0,255,1,0,0,255,1,0,0,255,1,0

 ds 175,0
PlayerShape:
 byte $3c,$7e,$18,$7e,$1e,$3c,$18,$24,$42
 ds 175,0
 include "room.inc"
 ORG $fffa
 word Reset,Reset,Reset
