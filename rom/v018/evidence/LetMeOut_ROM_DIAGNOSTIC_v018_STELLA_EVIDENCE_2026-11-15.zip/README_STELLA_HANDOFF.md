# Let Me Out! – v0.18 complete developer handoff (Stella evidence addendum)

The original 35-file ROM delivery from 2026-11-15 is included unchanged as `original/LetMeOut_ROM_DIAGNOSTIC_v018_NTSC_F6.zip`.
The new Stella 6.7.1 debugger evidence and real DASM rebuild results are in `evidence/`, and 16-case developer verdict and technical report in `docs/`.

**Failure of graphics criteria:** R1 silhouettes not legible, no full game, independent VERIFICATION not yet performed.

Do not treat original schematic screenshots as Stella captures. Do not confuse eight sampled 262-scanline frames with 600 contiguous verified frames per scene.

GitHub branch: rom-dev/v018-ntsc-diagnostic; PR: https://github.com/Odourman/let-me-out/pull/7
