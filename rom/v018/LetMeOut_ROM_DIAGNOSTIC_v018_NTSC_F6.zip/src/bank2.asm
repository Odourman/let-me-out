
; Let Me Out! v0.18 ROM DEVELOPMENT diagnostic, independently written 6502.
; 16K F6: four identical 6502 kernels with distinct data banks.
; Main starts in last F6 bank, switches banks by write to $FFF6..$FFF9.
; Timing: 3 VSYNC + 37 VBLANK + 192 visible + 30 overscan = 262.
; The playfield is updated asymmetrically: left PF0..2 then right PF0..2.
VSYNC = $00
VBLANK = $01
WSYNC = $02
NUSIZ0 = $04
NUSIZ1 = $05
COLUP0 = $06
COLUP1 = $07
COLUPF = $08
COLUBK = $09
CTRLPF = $0A
PF0 = $0D
PF1 = $0E
PF2 = $0F
RESP0 = $10
RESP1 = $11
GRP0 = $1B
GRP1 = $1C
SCENE = $80
FRAMELO = $81
FRAMEHI = $82
PHASE = $83
KEY_X = $84
KEY_Y = $85
KEY_ALIVE = $86
DOORCOLOR = $87
ORG $F000
Reset:
 SEI
 CLD
 LDX #$FF
 TXS
 LDX #$00
 TXA
ClearPage:
 STA $00,X
 INX
 BNE ClearPage
 LDA #$00
 STA SCENE
 LDA #$FE
 STA FRAMELO
 LDA #$FF
 STA FRAMEHI
 LDA #27
 STA KEY_X
 LDA #80
 STA KEY_Y
 LDA #1
 STA KEY_ALIVE
 LDA #$02
 STA VBLANK
Frame:
 LDA #$02
 STA VSYNC
 STA WSYNC
 STA WSYNC
 STA WSYNC
 LDA #$00
 STA VSYNC
 LDA #$02
 STA VBLANK
 ; line 3: 600-frame deterministic scene advance
 INC FRAMELO
 BNE CountReady
 INC FRAMEHI
CountReady:
 LDA FRAMEHI
 CMP #2
 BNE KeepScene
 LDA FRAMELO
 CMP #88
 BNE KeepScene
 LDA #0
 STA FRAMELO
 STA FRAMEHI
 INC SCENE
 LDA SCENE
 AND #3
 STA SCENE
KeepScene:
 STA WSYNC
 ; line 4: F6 bank switch; all bank kernel bytes are identical
 LDA SCENE
 BEQ UseBank0
 CMP #1
 BEQ UseBank1
 CMP #2
 BEQ UseBank2
 STA $FFF9
 JMP BankSelected
UseBank0:
 STA $FFF6
 JMP BankSelected
UseBank1:
 STA $FFF7
 JMP BankSelected
UseBank2:
 STA $FFF8
BankSelected:
 STA WSYNC
 ; line 5: phase index 0x40/0x50/0x60/0x70
 LDA FRAMELO
 AND #$C0
 LSR A
 LSR A
 CLC
 ADC #$40
 STA PHASE
 ; set P1 color ahead of time, so the VBLANK line 8 never overflows
 LDA #$2C
 STA DOORCOLOR
 LDA SCENE
 CMP #2
 BNE DoorColorChosen
 LDA FRAMELO
 CMP #85
 BCC ColorBrown
 CMP #170
 BCC ColorOrange
 LDA #0
 STA DOORCOLOR
 JMP DoorColorChosen
ColorBrown:
 LDA #$64
 STA DOORCOLOR
 JMP DoorColorChosen
ColorOrange:
 LDA #$3C
 STA DOORCOLOR
DoorColorChosen:
 LDX #9
 STA WSYNC
 ; line 6: player P0 coarse horizontal positioning
P0Delay:
 DEX
 BNE P0Delay
 STA RESP0
 LDA SCENE
 CMP #2
 BEQ PositionDoor
 LDX #11
 JMP PositionP1
PositionDoor:
 LDX #14
PositionP1:
 STA WSYNC
 ; line 7: P1 horizontal positioning. 14*5-1+STA+WSYNC <=76 cycles
P1Delay:
 DEX
 BNE P1Delay
 STA RESP1
 STA WSYNC
 ; line 8: scene colors and independently programmable right half
 LDA #$00
 STA COLUBK
 STA PF1
 STA PF2
 STA GRP0
 STA GRP1
 LDA #$10
 STA PF0
 ; CTRLPF reflect=0: the right half is independently loaded after the midpoint.
 ; Reflect=1 would reverse the byte order of the intended right-half map.
 LDA #0
 STA CTRLPF
 LDA #$1E
 STA COLUP0
 LDA #$0E
 STA COLUPF
 LDA DOORCOLOR
 STA COLUP1
 STA WSYNC
 ; line 9 + thirty WSYNC lines = line 39, still VBLANK
 LDX #30
BlankFill:
 STA WSYNC
 DEX
 BNE BlankFill
 LDY #64
 LDA #0
 STA GRP0
 STA GRP1
 ; release VBLANK only near end of line 39 (in horizontal blank)
 NOP
 NOP
 NOP
 NOP
 NOP
 NOP
 NOP
 NOP
 NOP
 NOP
 NOP
 NOP
 NOP
 NOP
 NOP
 NOP
 NOP
 NOP
 NOP
 NOP
 NOP
 NOP
 NOP
 NOP

 STA VBLANK
 STA WSYNC
 ; line 40: first visible scanline is border, remaining 191 drawn below.
 LDA SCENE
 CMP #1
 BEQ BandRenderer
 CMP #3
 BEQ BandRenderer
 LDY #65
 JMP FullLoop

; Bank 1 and 3 stress renderer; 80 top + 11 stress + 101 bottom lines.
BandRenderer:
 LDX #79
BandTop:
 STA WSYNC
 DEX
 BNE BandTop
 LDA #0
 STA CTRLPF
 LDA #$0E
 STA COLUPF
 LDY PHASE
 LDA P0DATA,Y
 STA GRP0
 LDA P1DATA,Y
 STA GRP1
 LDX #11
BandLoop:
 STA WSYNC
 LDA LEFT0,Y
 STA PF0
 LDA LEFT1,Y
 STA PF1
 LDA LEFT2,Y
 STA PF2
 NOP
 NOP
 NOP
 NOP

 LDA RIGHT0,Y
 STA PF0
 LDA RIGHT1,Y
 STA PF1
 LDA RIGHT2,Y
 STA PF2
 INY
 LDA P0DATA,Y
 STA GRP0
 LDA P1DATA,Y
 STA GRP1
 DEX
 BNE BandLoop
 ; line 131: first lower half line
 STA WSYNC
 LDA #0
 STA GRP0
 STA GRP1
 STA PF1
 STA PF2
 LDA #$10
 STA PF0
 LDA #1
 STA CTRLPF
 LDA #$64
 STA COLUPF
 LDX #100
BandBottom:
 STA WSYNC
 DEX
 BNE BandBottom
 JMP EndVisible

; Banks 0/2: one inactive top line + 191 rendered scanlines.
FullLoop:
 STA WSYNC
 LDA LEFT0,Y
 STA PF0
 LDA LEFT1,Y
 STA PF1
 LDA LEFT2,Y
 STA PF2
 NOP
 NOP
 NOP
 NOP

 LDA RIGHT0,Y
 STA PF0
 LDA RIGHT1,Y
 STA PF1
 LDA RIGHT2,Y
 STA PF2
 INY
 LDA P0DATA,Y
 STA GRP0
 LDA P1DATA,Y
 STA GRP1
 TYA
 BNE FullLoop
EndVisible:
 STA WSYNC
 LDA #2
 STA VBLANK
 LDX #29
Overscan:
 STA WSYNC
 DEX
 BNE Overscan
 STA WSYNC
 JMP Frame
; Tables begin at fixed $F400 in every bank. Unused bytes read as $FF.
ORG $F400
LEFT0:
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $10,$10,$10,$10,$10,$10,$10,$10,$F0,$F0,$F0,$F0,$F0,$F0,$F0,$F0
 BYTE $10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10
 BYTE $10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10
 BYTE $10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10
 BYTE $10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10
 BYTE $10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10
 BYTE $10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10
 BYTE $10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10
 BYTE $10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10
 BYTE $10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10
 BYTE $10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10,$10
 BYTE $F0,$F0,$F0,$F0,$F0,$F0,$F0,$F0,$10,$10,$10,$10,$10,$10,$10,$10

LEFT1:
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF
 BYTE $FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$C0,$C0,$C0,$C0,$C0,$C0,$C0,$C0
 BYTE $C0,$C0,$C0,$C0,$C0,$C0,$C0,$C0,$01,$01,$01,$01,$01,$01,$01,$01
 BYTE $0C,$0C,$0C,$0C,$0C,$0C,$0C,$0C,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$0C,$0C,$0C,$0C,$0C,$0C,$0C,$0C
 BYTE $01,$01,$01,$01,$01,$01,$01,$01,$C0,$C0,$C0,$C0,$C0,$C0,$C0,$C0
 BYTE $C0,$C0,$C0,$C0,$C0,$C0,$C0,$C0,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF
 BYTE $FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$00,$00,$00,$00,$00,$00,$00,$00

LEFT2:
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$01,$01,$01,$01,$01,$01,$01,$01
 BYTE $01,$01,$01,$01,$01,$01,$01,$01,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$3F,$3F,$3F,$3F,$3F,$3F,$3F,$3F
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $3F,$3F,$3F,$3F,$3F,$3F,$3F,$3F,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$01,$01,$01,$01,$01,$01,$01,$01
 BYTE $01,$01,$01,$01,$01,$01,$01,$01,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$00,$00,$00,$00,$00,$00,$00,$00

RIGHT0:
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$F0,$F0,$F0,$F0,$F0,$F0,$F0,$F0
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$C0,$C0,$C0,$C0,$C0,$C0,$C0,$C0
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $C0,$C0,$C0,$C0,$C0,$C0,$C0,$C0,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $F0,$F0,$F0,$F0,$F0,$F0,$F0,$F0,$00,$00,$00,$00,$00,$00,$00,$00

RIGHT1:
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$1F,$1F,$1F,$1F,$1F,$1F,$1F,$1F
 BYTE $1F,$1F,$1F,$1F,$1F,$1F,$1F,$1F,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$F8,$F8,$F8,$F8,$F8,$F8,$F8,$F8
 BYTE $03,$03,$03,$03,$03,$03,$03,$03,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$03,$03,$03,$03,$03,$03,$03,$03
 BYTE $F8,$F8,$F8,$F8,$F8,$F8,$F8,$F8,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$1F,$1F,$1F,$1F,$1F,$1F,$1F,$1F
 BYTE $1F,$1F,$1F,$1F,$1F,$1F,$1F,$1F,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$00,$00,$00,$00,$00,$00,$00,$00

RIGHT2:
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $80,$80,$80,$80,$80,$80,$80,$80,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF
 BYTE $80,$80,$80,$80,$80,$80,$80,$80,$80,$80,$80,$80,$80,$80,$80,$80
 BYTE $80,$80,$80,$80,$80,$80,$80,$80,$8F,$8F,$8F,$8F,$8F,$8F,$8F,$8F
 BYTE $8F,$8F,$8F,$8F,$8F,$8F,$8F,$8F,$8C,$8C,$8C,$8C,$8C,$8C,$8C,$8C
 BYTE $8C,$8C,$8C,$8C,$8C,$8C,$8C,$8C,$80,$80,$80,$80,$80,$80,$80,$80
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $80,$80,$80,$80,$80,$80,$80,$80,$8C,$8C,$8C,$8C,$8C,$8C,$8C,$8C
 BYTE $8C,$8C,$8C,$8C,$8C,$8C,$8C,$8C,$8F,$8F,$8F,$8F,$8F,$8F,$8F,$8F
 BYTE $8F,$8F,$8F,$8F,$8F,$8F,$8F,$8F,$80,$80,$80,$80,$80,$80,$80,$80
 BYTE $80,$80,$80,$80,$80,$80,$80,$80,$80,$80,$80,$80,$80,$80,$80,$80
 BYTE $FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$80,$80,$80,$80,$80,$80,$80,$80

P0DATA:
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00

P1DATA:
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $3C,$3C,$3C,$3C,$3C,$3C,$3C,$3C,$3C,$3C,$3C,$3C,$66,$66,$66,$66
 BYTE $76,$76,$76,$76,$3C,$3C,$3C,$3C,$3C,$3C,$3C,$3C,$3C,$3C,$3C,$3C
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
 BYTE $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
ORG $FFFC
 WORD Reset,Reset
