ParkKeyBall:
 lda #86
 ldx #4
 jmp Position
BallKeyRow:
 lda (P0Ptr),y
 sta GRP0
 lda (P1Ptr),y
 sta GRP1
 lda #$21
BallWidth:
 sta CTRLPF
 lda #2
BallEnable:
 sta $1f
 lda #$1a
BallGold:
 sta COLUPF
 nop
 nop
 lda #$26
BallBrown:
 sta COLUPF
 lda #0
 sta $1f
 iny
 jmp NextRoom
