RetriggerPair:
 txa
 pha
 ldx SmallMaleProbe-166,y
 lda FemaleProbe-166,y
LeftMask:
 sta GRP1
 bit PX
 nop
LeftReset:
 sta RESP1
 nop
RightMask:
 stx GRP1
RightReset:
 stx RESP1
 lda (P0Ptr),y
 sta GRP0
 pla
 tax
 iny
 jmp NextRoom
FemaleProbe:
 byte 60,60,24,255,60,126,126,36,36
SmallMaleProbe:
 byte 0,0,60,60,24,126,24,36,0
