ReserveP1ForKey:
 lda PY
 cmp #151
 bne ReserveKeyDone
 lda #255
 sta SetupRows+3
ReserveKeyDone:
 rts
