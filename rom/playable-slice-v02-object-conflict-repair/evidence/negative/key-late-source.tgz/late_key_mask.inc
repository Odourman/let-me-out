LoadLateKeyMask:
 sta P1Ptr+1
 lda QueueLo,x
 sta P1Ptr
 iny
 lda (P1Ptr),y
 sta QueueFirst,x
 rts
