RightPfCut:
 lda DoorColor
 cpy #164
 bcc RightPfDone
 cpy #172
 bcs RightPfDone
 lda #0
RightPfDone:
 rts
